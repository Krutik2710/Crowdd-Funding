
<?php 
session_start();
include 'common/connect.php';


$result = $obj->query("SELECT * from user where role_id=2");
$row = mysqli_num_rows($result);

$result1 = $obj->query("SELECT * from user WHERE role_id=3");
$row1 = mysqli_num_rows($result1);

$result2 = $obj->query("SELECT * from event WHERE STATUS='complete'");
$row2 = mysqli_num_rows($result2);

$result3 = $obj->query("SELECT * from donation WHERE STATUS='accept'");
$row3 = mysqli_num_rows($result3);

$sql = $obj->query("SELECT SUM(amount) FROM money_donation");
while ($row4 = mysqli_fetch_array($sql)) {
   
    $sum = $row4['SUM(amount)'];
}
?>
<!doctype html>
<html lang="zxx">

<head>
	
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>CROWD FUNDING
	</title>
	
	<link rel="stylesheet" href="assets/css/style-starter.css">
	
	<link href="//fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700&display=swap" rel="stylesheet">
	
</head>

<body>

	
<?php include 'common/header.php' ?>

	
	<section class="w3l-main-slider position-relative" id="home">
		<div class="companies20-content">
			<div class="owl-one owl-carousel owl-theme">
				<div class="item">
					<li>
						<div class="slider-info banner-view banner-top3 bg bg2">
							<div class="banner-info">
								<div class="container">
									<div class="banner-info-bg">
										<h5>Creative a Better Future through your Help</h5>
										<div class="banner-buttons">
											<a class="btn btn-style btn-primary" href="register.php">Volunteer</a>
											<a href="#small-dialog2" class="popup-with-zoom-anim play-view">
												<span class="video-play-icon">
													<span class="fa fa-play"></span>
												</span>
												<h6>How We Works</h6>

											</a>
											
											<div id="small-dialog2" class="zoom-anim-dialog mfp-hide">
												<iframe src="https://player.vimeo.com/video/164890650"
													allow="autoplay; fullscreen" allowfullscreen=""></iframe>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</li>
				</div>
			</div>
		</div>
	</section>
	
	<div class="w3l-bottom-grids">
		<div class="container-fluid px-0">
			<div class="bottomhny-grids-sec">
				<div class="bottomhny-1">
					<div class="bottomhny-gd-ingf">
						<h4>Charity is a simple method to prove kindness</h4>
					</div>
				</div>
				<div class="bottomhny-1 bottomhny-2">
					<div class="bottomhny-gd-ingf">
						<h4>By giving a little, you will help out a lot.</h4>
					</div>
				</div>
				<div class="bottomhny-1 bottomhny-1-img">
					<div class="bottomhny-gd-ingf">

					</div>
				</div>

			</div>
		</div>
	</div>
	
	<section class="features-4">
		<div class="features4-block py-5">
			<div class="container py-lg-4">
				<div class="title-content text-center mb-lg-5 mt-4">
					<h6 class="sub-title">Why Choose Us</h6>
					<h3 class="hny-title">How Can Help?</h3>
				</div>
				<div class="row features4-grids text-left mt-lg-6">
					<div class="col-lg-4 col-md-6 features4-grid mt-4">
						<div class="features4-grid-inn">
							<div class="img-featured">
								<div class="ch-item ch-img-1">
									<div class="ch-info-wrap">
										<div class="ch-info">
											<div class="ch-info-front ch-img-1"></div>
											<div class="ch-info-back">
												<h4>Donate</h4>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="features4-rightinfo">
								<h5><a href="#URL">Give Donation</a></h5>
								<p>Help others and be happy ,and god will do the rest,and play your role in the constructive cause.</p>

							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-6 features4-grid mt-4">
						<div class="features4-grid-inn">
							<div class="img-featured">
								<div class="ch-item ch-img-2">
									<div class="ch-info-wrap">
										<div class="ch-info">
											<div class="ch-info-front ch-img-2"></div>
											<div class="ch-info-back">
												<h4>Volunteer</h4>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="features4-rightinfo">
								<h5><a href="register.php">
										Become A Volunteer</a></h5>
								<p>Discover why some of the richest people in the world are not millionaires, they are volunteers,
do Small Things With Great Love,volunteering is a Work of Heart</p>

							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-6 features4-grid mt-4">
						<div class="features4-grid-inn">
							<div class="img-featured">
								<div class="ch-item ch-img-3">
									<div class="ch-info-wrap">
										<div class="ch-info">
											<div class="ch-info-front ch-img-3"></div>
											<div class="ch-info-back">
												<h4>Donate</h4>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="features4-rightinfo">
								<h5><a href="#URL">
										Give Food and clothe donations..</a></h5>
								<p>Even the smallest of contributions are used to build a better future for tomorrow.</p>

							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		</div>
	</section>
	
	<section class="w3l-specification-6">
		<div class="specification-6-mian py-5">
			<div class="container py-lg-5">
				<div class="row story-6-grids">
					<div class="col-lg-10 story-gd pl-lg-4  text-center mx-auto">
						<div class="title-content px-lg-5">
							<h6 class="sub-title" style="color:#FF4500 ">Our Organization</h6>
							<h3 class="hny-title two">Want to get involved?</h3>
							<p class="mt-3 mb-lg-5 px-lg-5 counter-para"> Volunteering can be provided with the organisations already working in the area of your interest or the volunteers.</p>
						</div>
						<div class="skill_info mt-lg-5 mt-4 pt-lg-4">
							<div class="stats_left">
								<div class="counter_grid">
									<div class="icon_info">
										<p class="counter"><?php echo $row; ?></p>
										<h4>Number of supporters</h4>

									</div>
								</div>
							</div>
							<div class="stats_left">
								<div class="counter_grid">
									<div class="icon_info">
										<p class="counter"><?php echo $sum; ?></p>
										<h4>Fund raised</h4>

									</div>
								</div>
							</div>
							<div class="stats_left">
								<div class="counter_grid">
									<div class="icon_info">
										<p class="counter"><?php echo $row3; ?></p>
										<h4>Other Doantions</h4>

									</div>
								</div>
							</div>
							<div class="stats_left">
								<div class="counter_grid">
									<div class="icon_info">
										<p class="counter"><?php echo $row1; ?></p>
										<h4>Volunteers Worldwide</h4>

									</div>
								</div>
							</div>
						</div>
						<br><br><br>
						<div class="title-content">
								<h6 class="sub-title" style="color: #FF4500;">Join Us</h6>
								<h3 class="hny-title two">Become A Volunteer</h3>
								<p class="counter-para">Join your hand with us for a better life and beautiful future</p>

							</div>
							<a href="login.php" class="btn btn-style -btn mt-4">Donate Now</a>
							<a href="contact.php" class="btn btn-style btn-primary mt-4">Inquiry </a>
						</div>
					</div>

				</div>
			</div>
		</div>
	</section>
	
	

	<?php include 'common/footer.php' ?>
	
</body>

</html>

<script src="assets/js/jquery-3.3.1.min.js"></script>


<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script>
	$(document).ready(function () {
		$('.popup-with-zoom-anim').magnificPopup({
			type: 'inline',

			fixedContentPos: false,
			fixedBgPos: true,

			overflowY: 'auto',

			closeBtnInside: true,
			preloader: false,

			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-zoom-in'
		});

		$('.popup-with-move-anim').magnificPopup({
			type: 'inline',

			fixedContentPos: false,
			fixedBgPos: true,

			overflowY: 'auto',

			closeBtnInside: true,
			preloader: false,

			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-slide-bottom'
		});
	});
</script>

<script src="assets/js/jquery.waypoints.min.js"></script>
<script src="assets/js/jquery.countup.js"></script>
<script>
	$('.counter').countUp();
</script>

<script src="assets/js/owl.carousel.js"></script>

<script>
	$(document).ready(function () {
		$('.owl-one').owlCarousel({
			loop: true,
			margin: 0,
			nav: false,
			responsiveClass: true,
			autoplay: false,
			autoplayTimeout: 5000,
			autoplaySpeed: 1000,
			autoplayHoverPause: false,
			responsive: {
				0: {
					items: 1,
					nav: false
				},
				480: {
					items: 1,
					nav: false
				},
				667: {
					items: 1,
					nav: true
				},
				1000: {
					items: 1,
					nav: true
				}
			}
		})
	})
</script>

<script>
	$(document).ready(function () {
		$('.owl-testimonial').owlCarousel({
			loop: true,
			margin: 0,
			nav: false,
			responsiveClass: true,
			autoplay: false,
			autoplayTimeout: 5000,
			autoplaySpeed: 1000,
			autoplayHoverPause: false,
			responsive: {
				0: {
					items: 1,
					nav: false
				},
				480: {
					items: 1,
					nav: false
				},
				667: {
					items: 1,
					nav: false
				},
				1000: {
					items: 1,
					nav: false
				}
			}
		})
	})
</script>

<script>
  $(function () {
    $('.navbar-toggler').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>



<script>
  $(window).on("scroll", function () {
    var scroll = $(window).scrollTop();

    if (scroll >= 80) {
      $("#site-header").addClass("nav-fixed");
    } else {
      $("#site-header").removeClass("nav-fixed");
    }
  });


  $(".navbar-toggler").on("click", function () {
    $("header").toggleClass("active");
  });
  $(document).on("ready", function () {
    if ($(window).width() > 991) {
      $("header").removeClass("active");
    }
    $(window).on("resize", function () {
      if ($(window).width() > 991) {
        $("header").removeClass("active");
      }
    });
  });
</script>

<script src="assets/js/bootstrap.min.js"></script>
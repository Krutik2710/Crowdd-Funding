<div class="footer">
	   <p> <a href="../user1/home.php" target="_blank">CROWD_FUNDING</a></p>		
	</div>